PĀLI: A REFERENCE GRAMMAR AND WORKBOOK
======================================

Version 1.2 · 17 November 2026. Both books as markdown.

  grammar/sajjhaya-pali.md            the grammar, whole
  grammar/sections/                   the grammar one file per section, in
                                      reading order: front matter, the
                                      eighteen chapters, Appendices A to E
  workbook/sajjhaya-pali-workbook.md  the workbook, whole
  workbook/sections/                  the workbook one file per section:
                                      exercises, reviews, answers

Each section file stands alone, with its own heading and its own footnotes.
The PDFs, the offline HTML and the website are at
https://github.com/sajjhaya/pali

Licence: CC BY-NC-SA 4.0. The paradigm tables in Appendix A and some quoted
material carry terms of their own; the LICENSE file beside the downloads
gives them in full.
